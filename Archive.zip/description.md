## Project name
Floating Cities

## Project description
A study in composition with ambient occlusion inspired by ideas of Italo Calvino.

1 Density & Composition
2 Color
3 Equator Rotation
4 Polar Rotation 
5 Distance

Orbit, pan, and zoom the camera using touch or mouse.

## Number of editions
100

## Price
3

## Your address
tz1XWDVQJgcxbiQb5nniCAZpuyy4fn4fRBpv